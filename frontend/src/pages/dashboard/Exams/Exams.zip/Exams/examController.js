const Exam = require("../models/examModel");
const Material = require("../models/materialModel");
const { generateExamQuestions } = require("../utils/aiService");

exports.generateExam = async (req, res) => {
  try {
    const { materialId, config } = req.body;

    if (!materialId || !config) {
      return res.status(400).json({ message: "Material ID and config are required" });
    }

    // Validate config
    const requiredFields = ['scope', 'difficulty', 'questionTypes', 'mode'];
    for (const field of requiredFields) {
      if (!config[field]) {
        return res.status(400).json({ message: `${field} is required in config` });
      }
    }

    // Check if at least one question type is selected
    const hasQuestionType = Object.values(config.questionTypes).some(type => type === true);
    if (!hasQuestionType) {
      return res.status(400).json({ message: "At least one question type must be selected" });
    }

    // Check if material exists and belongs to user
    const material = await Material.findOne({ _id: materialId, userId: req.user.id });
    if (!material) {
      return res.status(404).json({ message: "Material not found" });
    }

    // Create exam record
    const exam = await Exam.create({
      userId: req.user.id,
      materialId: materialId,
      title: `${material.title} - Exam`,
      config: config,
      status: "generating",
    });

    // Generate questions asynchronously
    setImmediate(async () => {
      try {
        const questions = await generateExamQuestions(material.extractedText, config);

        await Exam.findByIdAndUpdate(exam._id, {
          questions: questions,
          totalQuestions: questions.length,
          status: "ready",
        });

        console.log(`Exam ${exam._id} generated successfully with ${questions.length} questions`);
      } catch (error) {
        console.error("Exam generation failed:", error);
        await Exam.findByIdAndUpdate(exam._id, {
          status: "failed",
        });
      }
    });

    return res.status(201).json({
      success: true,
      message: "Exam generation started",
      examId: exam._id,
      status: "generating",
    });

  } catch (error) {
    console.error("Generate exam error:", error);
    return res.status(500).json({ message: "Failed to generate exam" });
  }
};

exports.getExam = async (req, res) => {
  try {
    const { examId } = req.params;

    const exam = await Exam.findOne({ _id: examId, userId: req.user.id })
      .populate('materialId', 'title')
      .select('-questions.correct'); // Don't send correct answers

    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    return res.status(200).json({
      success: true,
      exam: {
        _id: exam._id,
        title: exam.title,
        materialTitle: exam.materialId.title,
        config: exam.config,
        questions: exam.questions,
        status: exam.status,
        totalQuestions: exam.totalQuestions,
        createdAt: exam.createdAt,
      },
    });

  } catch (error) {
    console.error("Get exam error:", error);
    return res.status(500).json({ message: "Failed to fetch exam" });
  }
};

exports.getExamWithAnswers = async (req, res) => {
  try {
    const { examId } = req.params;

    const exam = await Exam.findOne({ _id: examId, userId: req.user.id })
      .populate('materialId', 'title');

    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    return res.status(200).json({
      success: true,
      exam: exam,
    });

  } catch (error) {
    console.error("Get exam with answers error:", error);
    return res.status(500).json({ message: "Failed to fetch exam" });
  }
};

exports.getUserExams = async (req, res) => {
  try {
    const exams = await Exam.find({ userId: req.user.id })
      .populate('materialId', 'title')
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      count: exams.length,
      exams: exams.map(exam => ({
        _id: exam._id,
        title: exam.title,
        materialTitle: exam.materialId.title,
        config: exam.config,
        status: exam.status,
        totalQuestions: exam.totalQuestions,
        createdAt: exam.createdAt,
      })),
    });

  } catch (error) {
    console.error("Get user exams error:", error);
    return res.status(500).json({ message: "Failed to fetch exams" });
  }
};

exports.saveExamResult = async (req, res) => {
  try {
    const { examId } = req.params;
    const { score, correctAnswers, totalQuestions, timeSpent, markedForReview, notAnswered, answers } = req.body;

    const exam = await Exam.findOne({ _id: examId, userId: req.user.id });
    if (!exam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    // Save result
    exam.result = {
      score,
      correctAnswers,
      totalQuestions,
      timeSpent,
      markedForReview,
      notAnswered,
      answers,
      completedAt: new Date(),
      isCompleted: true,
    };

    await exam.save();

    return res.status(200).json({
      success: true,
      message: "Exam result saved successfully",
      exam,
    });
  } catch (error) {
    console.error("Save exam result error:", error);
    return res.status(500).json({ message: "Failed to save exam result" });
  }
};

exports.retakeExam = async (req, res) => {
  try {
    const { examId } = req.params;

    const originalExam = await Exam.findOne({ _id: examId, userId: req.user.id });
    if (!originalExam) {
      return res.status(404).json({ message: "Exam not found" });
    }

    // Create a new exam with same config but different questions
    const newExam = await Exam.create({
      userId: req.user.id,
      materialId: originalExam.materialId,
      title: originalExam.title,
      config: originalExam.config,
      status: "generating",
      retakeOf: examId,
    });

    // Generate new questions asynchronously
    const Material = require("../models/materialModel");
    const material = await Material.findById(originalExam.materialId);
    
    setImmediate(async () => {
      try {
        const { generateExamQuestions } = require("../utils/aiService");
        const questions = await generateExamQuestions(material.extractedText, originalExam.config);

        await Exam.findByIdAndUpdate(newExam._id, {
          questions: questions,
          totalQuestions: questions.length,
          status: "ready",
        });

        console.log(`Retake exam ${newExam._id} generated successfully`);
      } catch (error) {
        console.error("Retake exam generation failed:", error);
        await Exam.findByIdAndUpdate(newExam._id, {
          status: "failed",
        });
      }
    });

    return res.status(201).json({
      success: true,
      message: "Retake exam created",
      examId: newExam._id,
      status: "generating",
    });
  } catch (error) {
    console.error("Retake exam error:", error);
    return res.status(500).json({ message: "Failed to create retake exam" });
  }
};